Juste pour vous montrer que l'on peut écrire différentes version d'un code :
- step1 : code où l'inspiration manquait, trop long !
- refactor1 : 1er refactoring, déjà un peu plus léger...
- refactor2 : l'inspiration est là, le code devient optimisé...
- refactor3 : utilisation de classes CSS pour rendre le code plus minimaliste.

En bonus, vous trouverez une version "full-css" offerte par un étudiant : )