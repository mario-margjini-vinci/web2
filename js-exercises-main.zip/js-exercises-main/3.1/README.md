# Infos
Le projet qui est mis en ligne correspond au dernier exercice du cours (Projet 4.3). Ceci afin de publier une application qui est sécurisée et qui s'approche d'un produit fini.

# URL
## frontend
https://e-vinci.github.io/mymovies/

## api
https://mymovies.azurewebsites.net/films
https://mymovies.azurewebsites.net/auths