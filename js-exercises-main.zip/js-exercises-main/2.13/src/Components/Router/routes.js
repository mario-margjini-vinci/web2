import HomePage from '../Pages/HomePage';

const routes = {
  '/': HomePage,
};

export default routes;
