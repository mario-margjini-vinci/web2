const AboutPage = () => {
  const main = document.querySelector('main');
  main.innerHTML = `
  <div class="container">
  <h4>About us</h4>
  <p>Hello, here at myMovies, we are passionate about...
  <b>MOVIES 📽❤</b>
  </p>
  </div>`;
};

export default AboutPage;
