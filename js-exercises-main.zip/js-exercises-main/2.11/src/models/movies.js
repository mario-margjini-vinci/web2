const movies = [];

const readAllMovies = () => movies;

const addOneMovie = (movie) => movies.push(movie);

export { readAllMovies, addOneMovie };
